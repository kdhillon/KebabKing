package com.chuanrchef.game;

public class Store {
	
	// static class that contains all information about purchasable items
	
// Meat Quality (1 to 5)
	int meatQuality;
	String meatQualityDescription =
			"Upgrade the quality of your meat! Better meat costs more, but sells for "
			+ "more and increases your reputation!. Some customers will only accept"
			+ " high quality meat! ";
	
// Beer Quality (1 to 5)	
	int beerQuality;
	String beerQualityDescription =
			"Upgrade the quality of your beer! Better beer costs more, but sells for "
			+ "more and increases your reputation!. Some customers will only accept"
			+ " high quality beer! ";
	
// Grill types:
	//	Regular Small, 
	//	Regular Large, 
	//	Storage Small, 
	//	Storage Big, 
	//	(Control Small), 
	//	(Control Big)
	enum GrillType{Regular, Storage, Control};
	enum GrillSize{Small, Big}
	
// Reputation upgrade
	
//	Food Upgrades
//	better grilles (multi-level grills, flame control grilles, storage grilles, that keep chuanr hot, etc)
//	buy better meat (1 by 1 - i.e. better chicken, better lamb, better beef, individually) (each chuar costs more, but sells for more)
//	buy better beer (each beer costs more, sells for more) - will not affect crowd size - that is determined by reputation. reputation goes up slowly as people stop getting sick and you give the right chuar to people
//	Reputation upgrades
//	Buy a street vendor permit
//	press release about your chuar stand
//	invite the health inspector for a free meal
//	Advertise in the local newspaper
//	Hire waitstaff to deliver your chuar to customers (graphics)
//	Guerrilla Marketing Campaign (pay students to talk about how good your chuar stand is)
//	upgrade your premises 
//	grille on a bicycle
//	grille on a motorcycle
//	grille on a table
//	grille on a permanent table
//	grille on a stand with seating
//	extra seating
//	restaurant
//	Change location 
//	village
//	suburb
//	small city
//	university district
//	Central Business District

}
