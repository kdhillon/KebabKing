package com.chuanrchef.game;

import com.chuanrchef.game.Grill.GrillType;

public class Profile {
	final float MAX_MONEY = 10000;
	final float MIN_MONEY = 0;
		
	GrillType grillType; 	// current grill
	float money; 			// current cash
	int daysWorked;
	float customerPatienceFactor = 1;
	float[] pastFiveDaysReputation = {2.5f, 2.5f, 2.5f, 2.5f, 2.5f};
	float currentReputation;
	float sicknessFactor;
	
	public Profile() {
		this.money = 50;
		this.daysWorked = 0;
		this.grillType = GrillType.SMALL;
		this.currentReputation = 2.5f;
	}
	
	// only used at the end of the day
	public void giveMoney(float money) {
		validateMoney();
		this.money += money;
		validateMoney();
	}
	
	public void updateRepuation(float dayReputation) {
		// slide everything back
		for (int i = 0; i < pastFiveDaysReputation.length - 1; i++) {
			pastFiveDaysReputation[i] = pastFiveDaysReputation[i+1];
		}
		pastFiveDaysReputation[4] = dayReputation;
		
		// calculate new current reputation
		float sum = 0;
		for (float rep : pastFiveDaysReputation) {
			sum += rep;
		}
		sum /= pastFiveDaysReputation.length;
		
		currentReputation = sum;
	}
	
	public float getCurrentReputation() {
		return currentReputation;
	}
	
	public void validateMoney() {
		if (this.money < MIN_MONEY || this.money > MAX_MONEY) {
			throw new java.util.InputMismatchException("money out of range");
		}
	}
	
	// optional?
//	public Profile(String name) {
//		
//	}
	
}
