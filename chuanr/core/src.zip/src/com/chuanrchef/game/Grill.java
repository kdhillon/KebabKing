package com.chuanrchef.game;

import java.util.ArrayList;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

// contains information for the grill, the trash, spice box, and ice chests
public class Grill {
	static final int GRILL_X = 1;
	static final int GRILL_Y = 2;
	static final int GRILL_WIDTH = 10;
	static final int GRILL_HEIGHT = 3;
	
	static final int GRILL_PIECE_WIDTH = 1;
	static final int GRILL_PIECE_HEIGHT = 3;
	static final double CHUANR_PER_PIECE = 1;

	// bottom values
	static final int BOX_HOR_WIDTH = 3;
	static final int BOX_HOR_HEIGHT = 2;
	static final int SPICE_WIDTH = 1;
	static final int SPICE_HEIGHT = 3;
	static final int TRASH_WIDTH = 1;
	static final int TRASH_HEIGHT = 3;
	static final int BEER_WIDTH = 3;
	static final int BEER_HEIGHT = 2;
	static final int CHICKEN_X = 0;
	static final int BEEF_X = 3;
	static final int LAMB_X = 6;
	static final int BOTTOM_Y = 0;
	static final int BEER_X = 9;
	static final int BEER_Y = 0;
	static final int SPICE_X = 11;
	static final int SPICE_Y = 2;
	static final int TRASH_X = 0;
	static final int TRASH_Y = 2;
	
	private float time;
	private int xOffset;
	private int yOffset;

	public enum Selected {
		NONE, CHICKEN, BEEF, LAMB, SPICE, BEER
	}
	
	Selected selected;
	
	/** if false, grill cannot be interacted with */
	boolean active; 
	KitchenScreen ks; // only non-null when active
	GrillType grillType;
	int size; 
	Meat[] meat;
	int mousedOver; // index of moused-over slot on grill?
//	boolean meatBoxSelected; // for use when highlighting grill
	
	boolean mousedOverTrash = false;
//	boolean boxSelectedNotHeld = false; // try to use this to differentiate between holding and clicking
	boolean meatSelectedNotHeld = false;
	boolean placedWhileHeld = false; // true when meat has been placed during the 'hold'
	int removeOnRelease = -1;
	
	ArrayList<Meat> selectedSet;
	
	// think of a good way to keep this flexible if we want to add more grills later on.
	enum GrillType { 
		SMALL(8), MEDIUM(8), LARGE(8), HUGE(16);
		int size;
		boolean warming;
		
		private GrillType(int size) {
			this.size = size;
		}
	}

	public Grill(Profile profile) {
		this.grillType = profile.grillType;
		
		this.mousedOver = -1;
		
		this.selectedSet = new ArrayList<Meat>();
		selected = Selected.NONE;		
		
		this.size = this.grillType.size;
		
		xOffset = (GRILL_WIDTH - size) / 2;
		
		this.size = grillType.size; 
		System.out.println(size);
		this.time = 0;
		clearMeat();
	}

	public void activate(KitchenScreen ks) {
		System.out.println("activating");
		this.ks = ks;
		this.active = true;
		clearMeat();
	}
	
	public void clearMeat() {
		int length = this.getGrillSize();
		this.meat = new Meat[(int) (length * CHUANR_PER_PIECE)];
	}
	
	public void deactivate() {
		System.out.println("deactivating");
		this.selected = Selected.NONE;
		this.ks = null;
		this.active = false;
	}
	
	public void act(float delta) {
		if (!active) {
			return;
		}
		
//		if (!this.newMeatSelected()) this.boxSelectedNotHeld = false;
		
		for (int i = 0; i < meat.length; i++) {
			Meat m = meat[i];
			if (m != null && !(m.chicken() && m.index2 == i))
				m.act(delta);
		}
		this.time += delta;
	}

	public void draw(SpriteBatch batch) {
		drawBoxes(batch);
		
		TextureRegion grillLeft = Assets.grillLeft.getKeyFrame(time);
		TextureRegion grillRight = Assets.grillRight.getKeyFrame(time);
		TextureRegion grillMid = Assets.grillMid.getKeyFrame(time);

		int xCount = xOffset;		

		int draw_width = GRILL_PIECE_WIDTH * KitchenScreen.UNIT_WIDTH;
		int draw_height = GRILL_PIECE_HEIGHT * KitchenScreen.UNIT_HEIGHT;

		int draw_x = (xCount + GRILL_X) * KitchenScreen.UNIT_WIDTH;
		int draw_y = (yOffset + GRILL_Y) * KitchenScreen.UNIT_HEIGHT;

		
		// draw left
		batch.draw(grillLeft, draw_x, draw_y, draw_width, draw_height); 
		xCount++;

		// draw middle
		while (xCount < GRILL_WIDTH - xOffset - 1) {
			draw_x = (xCount + GRILL_X) * KitchenScreen.UNIT_WIDTH;
			batch.draw(grillMid, draw_x, draw_y, draw_width, draw_height);
			xCount++;
		}

		// draw right		 
		draw_x = (xCount + GRILL_X) * KitchenScreen.UNIT_WIDTH;
		batch.draw(grillRight, draw_x, draw_y, 
				draw_width, draw_height); 

		if (active)
			drawMeat(batch);
	}


	public void touchInput(int x, int y) {		
		if (!active) return;
		
		// KitchenScreen.convert to unit coordinates
		int unit_x = KitchenScreen.getUnitX(x);
		int unit_y = KitchenScreen.getUnitY(y);

		// if not on grill
		Selected box = touchBox(unit_x, unit_y);
		if (box != Selected.NONE && !ks.paused) {
			select(box);
			return;
		}

		// if on grill
		if (onGrill(unit_x, unit_y) && (selected == Selected.NONE || meatSelected())) {
			int index = getGrillIndex(x, y);
			if (meat[index] != null) {	
				if (selectedSet.contains(meat[index])) {
					if (meatSelectedNotHeld) {
						//						System.out.println("removing from selected");
						removeOnRelease(index);
						//						selectedSet.remove(meat[index]);
					}
				}
				else select(index);
			}
			return;
		}
	}

	
	public void highlightTrash(SpriteBatch batch) {
		int trash_x = KitchenScreen.convertXWithBuffer(TRASH_X);
		int trash_y = KitchenScreen.convertYWithBuffer(TRASH_Y);
		int box_sq_width = KitchenScreen.convertWidth(TRASH_WIDTH);
		int box_sq_height = KitchenScreen.convertHeight(TRASH_HEIGHT);

		// make this see through
//		Color myColor = Color.RED;
//		myColor.a = .4f;
//		batch.setColor(myColor);
		batch.draw(Assets.white, trash_x, trash_y, box_sq_width, box_sq_height);
//		batch.setColor(1, 1, 1, 1);
	}

	public void drawBoxes(SpriteBatch batch) {
		int box_hor_width 	= KitchenScreen.convertWidth(BOX_HOR_WIDTH);
		int box_hor_height 	= KitchenScreen.convertHeight(BOX_HOR_HEIGHT);
		int spice_width 	= KitchenScreen.convertWidth(SPICE_WIDTH);
		int spice_height 	= KitchenScreen.convertHeight(SPICE_HEIGHT);
		int trash_width 	= KitchenScreen.convertWidth(TRASH_WIDTH);
		int trash_height 	= KitchenScreen.convertHeight(TRASH_HEIGHT);
		int box_ver_width 	= KitchenScreen.convertWidth(BEER_WIDTH);
		int box_ver_height 	= KitchenScreen.convertHeight(BEER_HEIGHT);

		int chicken_x 	= KitchenScreen.convertXWithBuffer(CHICKEN_X);
		int beef_x 		= KitchenScreen.convertXWithBuffer(BEEF_X);
		int lamb_x 		= KitchenScreen.convertXWithBuffer(LAMB_X);
		int bottom_y 	= KitchenScreen.convertYWithBuffer(BOTTOM_Y);
		int beer_x 		= KitchenScreen.convertXWithBuffer(BEER_X);
		int beer_y 		= KitchenScreen.convertYWithBuffer(BEER_Y);
		int spice_x 	= KitchenScreen.convertXWithBuffer(SPICE_X);
		int spice_y 	= KitchenScreen.convertYWithBuffer(SPICE_Y);
		int trash_x 	= KitchenScreen.convertXWithBuffer(TRASH_X);
		int trash_y 	= KitchenScreen.convertYWithBuffer(TRASH_Y);

		// draw boxes in their proper locations
		batch.setColor(1, 1, 1, 1);

		batch.draw(Assets.chickenBox, chicken_x, bottom_y, box_hor_width, box_hor_height);
		batch.draw(Assets.beefBox, 	beef_x, bottom_y, box_hor_width, box_hor_height);
		batch.draw(Assets.lambBox, lamb_x, bottom_y, box_hor_width, box_hor_height);
		batch.draw(Assets.beerBox, beer_x, beer_y, box_ver_width, box_ver_height);
		batch.draw(Assets.spiceBox,	spice_x, spice_y, spice_width, spice_height);
		batch.draw(Assets.trashBox, trash_x, trash_y, trash_width, trash_height);


		Color myColor = Color.WHITE;
		myColor.a = .4f;
		batch.setColor(myColor);
		switch (selected) {
		case NONE:
			break;
		case CHICKEN:
			batch.draw(Assets.white, chicken_x, bottom_y, box_hor_width, box_hor_height);
			break;
		case BEEF:
			batch.draw(Assets.white, beef_x, bottom_y, box_hor_width, box_hor_height);
			break;
		case LAMB:
			batch.draw(Assets.white, lamb_x, bottom_y, box_hor_width, box_hor_height);
			break;
		case BEER:
			batch.draw(Assets.white, beer_x, beer_y, box_ver_width, box_ver_height);
			break;
		case SPICE:
			batch.draw(Assets.white, spice_x, spice_y, spice_width, spice_height);
			break;
		}
		if (mousedOverTrash) {
			highlightTrash(batch);
		}
		batch.setColor(1, 1, 1, 1);
		
	}
	
	

	
	// removes meat at given index when touch is released
	public void removeOnRelease(int index) {
		removeOnRelease = index;
	}

	public void select(Selected newSelected) {
		this.selected = newSelected;
		this.selectedSet.clear();
//		this.boxSelectedNotHeld = false;
		this.meatSelectedNotHeld = false;
	}

	public void select(int grillIndex) {
		if (grillIndex < 0 || grillIndex > meat.length) throw new java.lang.ArrayIndexOutOfBoundsException();
		this.selected = Selected.NONE;
		this.selectedSet.add(meat[grillIndex]);
//		this.boxSelectedNotHeld = false;
		this.meatSelectedNotHeld = false;
	}

	// used for calculating "mouseOver"
	public void holdInput(int x, int y) {
		int unit_x = KitchenScreen.getUnitX(x);
		int unit_y = KitchenScreen.getUnitY(y);

		mousedOverTrash = false;
		if (meatSelected() && mousedOverTrash(unit_x, unit_y))
			mousedOverTrash = true;

		mousedOver = -1;
		if (onGrill(unit_x, unit_y)) 
			mousedOver = getGrillIndex(x, y);
		
		// if moused over grill and spice is selected then spice whatever is there
		if (mousedOver != -1 && meat[mousedOver] != null) {
			if (this.selected == Selected.SPICE) {
				dropSpice();
			}
			else if (this.selected == Selected.NONE || ((this.newMeatSelected() || this.selected == Selected.BEER) && !placedWhileHeld)) {
				if (!selectedSet.contains(meat[mousedOver])) {
					this.selected = Selected.NONE;
					selectedSet.add(meat[mousedOver]);
				}
			}
		}
		
		// drop fresh meat on grill
		if (mousedOver != -1 && this.newMeatSelected()) {
			if (meat[mousedOver] == null && open(mousedOver)) {
				ks.dropMeatOnGrill(toMeat(selected));
				this.placedWhileHeld = true;
			}
		}

		// only if a meat from the grill is selected
		if (meatSelected() || selected == Selected.BEER)
			ks.cm.updateMousedOver(x, y);
	}

	public void release(int x, int y) {
		if (!this.active) return;
		
		
		boolean gaveBeerToCustomer = false;
		// drop stuff onto grill 
		if (mousedOver()) {
			if (newMeatSelected()) {
//				// if already meat there, select it, but only if just touched
//				if (this.meat[this.mousedOver] != null && !placedWhileHeld) {
//					this.select(mousedOver);
//				}
				
				
//				if (open(mousedOver)) {
////					if (!boxSelectedNotHeld) select(Selected.NONE);
//					if (!boxSelectedNotHeld) {
//						System.out.println("BAD PLACE");
//						select(Selected.NONE);
//					}
//				}
//				else {
//					System.out.println("deselecting");
//					selected = Selected.NONE;
//				}
			}
			else if (meatSelected()) {
				// remove it from selected if clicking it twice
				if (!open(mousedOver)) {
					//					if (selectedSet.contains(meat[mousedOver]) && meatSelectedNotHeld) 
					//						selectedSet.remove(meat[mousedOver]);
				}
				else if (open(mousedOver) || 
						(meat[mousedOver] == selectedSet.get(0) && !meat[mousedOver].chicken())) {
					move();
					select(Selected.NONE);
				}
			}
			else if (selected == Selected.SPICE) {
				if (!open(mousedOver)) {
					if (!meat[mousedOver].spiced){
						dropSpice();
					}
					else if (selected != Selected.SPICE) {
						select(mousedOver); // unselect if double-spice
					}
					select(Selected.NONE);
				}
			}
		}
		// drop stuff into trash
		else if (mousedOverTrash && meatSelected()) {
			trashSelected();
		}
		// drop meat on customers
		else if (meatSelected() && ks.cm.mousedOver != null && ks.cm.mousedOver.order != null) {
			ks.earnMoney(ks.cm.mousedOver.giveMeat(selectedSet));
			removeSelected(); // deletes selected meat from grill;
			select(Selected.NONE);
		}
		// drop beer on customers
		else if (selected == Selected.BEER && ks.cm.mousedOver != null && ks.cm.mousedOver.order != null) {
			ks.spendMoney(KitchenScreen.BEER_BUY_PRICE);
			ks.earnMoney(ks.cm.mousedOver.giveBeer());
			gaveBeerToCustomer = true;
		}

		// remove on release
		if (removeOnRelease >= 0) {
			selectedSet.remove(meat[removeOnRelease]);
			removeOnRelease = -1;
		}

		//		select(Selected.NONE);

		// selectButNotHold
		int unit_x = KitchenScreen.getUnitX(x);
		int unit_y = KitchenScreen.getUnitY(y);
		Selected box = touchBox(unit_x, unit_y);

		// touched and released same box
		if (box == Selected.NONE) {
			System.out.println("box none");
			if (onGrill(unit_x, unit_y)) {
				if (selectedSet.contains(meat[getGrillIndex(x, y)])) 
					this.meatSelectedNotHeld = true;
			}
			else {
				if (!gaveBeerToCustomer) {
					select(Selected.NONE);
				}
			}
		}
		else {
			if (isMeat(box)) {
//				this.boxSelectedNotHeld = true;
			}
		}
		placedWhileHeld = false;
	}
	
	// converts from selected to Meat.Type
	public Meat.Type toMeat(Selected selected) {
		if (selected == Selected.CHICKEN) return Meat.Type.CHICKEN;
		if (selected == Selected.BEEF) return Meat.Type.BEEF;
		if (selected == Selected.LAMB) return Meat.Type.LAMB;
		return null;
	}
	
	/** 
	 * Given touched units, return the box that was touched, or none if no box was touched
	 */
	private Selected touchBox(int unit_x, int unit_y) {
		if (unit_x >= CHICKEN_X && unit_x < CHICKEN_X + BOX_HOR_WIDTH) {
			if (unit_y >= BOTTOM_Y && unit_y < BOTTOM_Y + BOX_HOR_HEIGHT){
				return Selected.CHICKEN;
			}
		}
		if (unit_x >= BEEF_X && unit_x < BEEF_X + BOX_HOR_WIDTH) {
			if (unit_y >= BOTTOM_Y && unit_y < BOTTOM_Y + BOX_HOR_HEIGHT){
				return Selected.BEEF;
			}
		}
		if (unit_x >= LAMB_X && unit_x < LAMB_X + BOX_HOR_WIDTH) {
			if (unit_y >= BOTTOM_Y && unit_y < BOTTOM_Y + BOX_HOR_HEIGHT){
				return Selected.LAMB;
			}
		}

		if (unit_x >= BEER_X && unit_x < BEER_X + BEER_WIDTH) {
			if (unit_y >= BEER_Y && unit_y < BEER_Y + BEER_HEIGHT){
				return Selected.BEER;
			}
		}

		if (unit_x >= SPICE_X && unit_x < SPICE_X + SPICE_WIDTH) {
			if (unit_y >= SPICE_Y && unit_y < SPICE_Y + SPICE_HEIGHT){
				return Selected.SPICE;
			}
		}

		return Selected.NONE;
	}

	public boolean mousedOverTrash(int unit_x, int unit_y) {
		if (unit_x >= TRASH_X && unit_x < TRASH_X + TRASH_WIDTH) {
			if (unit_y >= TRASH_Y && unit_y < TRASH_Y + TRASH_HEIGHT){
				return true;
			}
		}
		return false;
	}

	public boolean isMeat(Selected selected) {
		return (selected == Selected.CHICKEN || selected == Selected.BEEF || selected == Selected.LAMB);
	}

	private int getGrillSize() {
		return grillType.size;
	}
	
	public boolean onGrill(int unit_x, int unit_y) {
		if (unit_x >= GRILL_X + this.xOffset && unit_x < GRILL_X + GRILL_WIDTH - xOffset) {
			if (unit_y >= GRILL_Y + this.yOffset && unit_y < GRILL_Y + GRILL_HEIGHT - yOffset) {
				return true;
			}
		}
		return false;
	}
	
	// can add vertical grills later
	public int getGrillIndex(int x, int y) {
		int distanceFromLeft = x - (GRILL_X + xOffset) * KitchenScreen.UNIT_WIDTH; 		
		return (int) (distanceFromLeft * CHUANR_PER_PIECE / (KitchenScreen.UNIT_WIDTH * GRILL_PIECE_WIDTH));
	}
	
//	public void highlightIndex(SpriteBatch batch, int i) {
//		int x = (int) (i * (KitchenScreen.UNIT_WIDTH * GRILL_PIECE_WIDTH / CHUANR_PER_PIECE) + KitchenScreen.UNIT_WIDTH * (xOffset + GRILL_X));
//		int y = KitchenScreen.UNIT_HEIGHT * (GRILL_Y + yOffset);
//		
//		batch.draw(Assets.white, x, y,  (int) (GRILL_PIECE_WIDTH * KitchenScreen.UNIT_WIDTH / 
//				CHUANR_PER_PIECE), KitchenScreen.UNIT_HEIGHT * GRILL_PIECE_HEIGHT);
//	}
	
	private int getXForIndex(int i) {
		return  (int) (i * (KitchenScreen.UNIT_WIDTH * GRILL_PIECE_WIDTH / CHUANR_PER_PIECE) + KitchenScreen.UNIT_WIDTH * (xOffset + GRILL_X));
	}

	private int getYForIndex(int i) {
		return  KitchenScreen.UNIT_HEIGHT * (GRILL_Y + yOffset);
	}
	
	public void drawMeat(SpriteBatch batch) {
		for (Meat m : meat) {
			if (m == null) continue;
			int x = getXForIndex(m.index1);
			int y = getYForIndex(m.index1);
			m.draw(batch, x, y);
		}
//		System.out.println(meatBoxSelected);
		

		// if placing meat on grill or moving meat
//		if (this.mousedOver() ) {
			
//			batch.setColor(1, 1, 1, .6f);
//			TextureRegion toDraw = null;
//			int widthFactor = 1;
//			if ((selected == Selected.CHICKEN) && this.canFit(Meat.Type.CHICKEN)) {
//				toDraw = Assets.chuanrChickenRaw;
//				widthFactor = 2;
//			}
//			if (selected == Selected.BEEF && this.canFit(Meat.Type.BEEF))
//				toDraw = Assets.chuanrBeefRaw;
//			if (selected == Selected.LAMB && this.canFit(Meat.Type.LAMB))
//				toDraw = Assets.chuanrLambRaw;			
//			
//			if (toDraw != null)
//				batch.draw(toDraw, getXForIndex(mousedOver), getYForIndex(mousedOver),  (int) (GRILL_PIECE_WIDTH * widthFactor * KitchenScreen.UNIT_WIDTH / 
//					CHUANR_PER_PIECE), KitchenScreen.UNIT_HEIGHT * GRILL_PIECE_HEIGHT);
//		}
		if (this.mousedOver() && this.meatSelected() && !this.selectedSet.contains(meat[mousedOver])) {
			// draw where all the meat will go if dropped!
			// for now, just draw the first one
			batch.setColor(1, 1, 1, .6f);
			TextureRegion toDraw = null;
			int widthFactor = 1;
			if (this.selectedSet.get(0).type == Meat.Type.CHICKEN && this.canFit(Meat.Type.CHICKEN)) {
				toDraw = Assets.chuanrChickenRaw;
				widthFactor = 2;
			}
			if (this.selectedSet.get(0).type == Meat.Type.BEEF  && this.canFit(Meat.Type.BEEF))
				toDraw = Assets.chuanrBeefRaw;
			if (this.selectedSet.get(0).type == Meat.Type.LAMB  && this.canFit(Meat.Type.LAMB))
				toDraw = Assets.chuanrLambRaw;			
			
			if (toDraw != null)
				batch.draw(toDraw, getXForIndex(mousedOver), getYForIndex(mousedOver),  (int) (GRILL_PIECE_WIDTH * widthFactor * KitchenScreen.UNIT_WIDTH / 
					CHUANR_PER_PIECE), KitchenScreen.UNIT_HEIGHT * GRILL_PIECE_HEIGHT);
		}
		if (this.meatSelected()) {
			for (Meat m : selectedSet) {
				Color myColor = Color.WHITE;
				myColor.a = .2f;
				batch.setColor(myColor);
				batch.draw(Assets.white, getXForIndex(m.index1), getYForIndex(m.index1),  (int) (GRILL_PIECE_WIDTH * KitchenScreen.UNIT_WIDTH / 
					CHUANR_PER_PIECE), KitchenScreen.UNIT_HEIGHT * GRILL_PIECE_HEIGHT);
				if (m.chicken()) 
					batch.draw(Assets.white, getXForIndex(m.index2), getYForIndex(m.index2),  (int) (GRILL_PIECE_WIDTH * KitchenScreen.UNIT_WIDTH / 
							CHUANR_PER_PIECE), KitchenScreen.UNIT_HEIGHT * GRILL_PIECE_HEIGHT);
			}
			batch.setColor(1, 1, 1, 1);
		}
	}
	
	// drops meat at mousedOver index
	public void dropMeat(Meat.Type type) {
		Meat toDrop = new Meat(type);
		
		if (!canFit(toDrop)) return;
		meat[mousedOver] = toDrop;
		meat[mousedOver].setIndex(mousedOver);
		if (type == Meat.Type.CHICKEN) {
			meat[mousedOver + 1] = meat[mousedOver];
		}
		
//		this.boxSelectedNotHeld = false;
	}
	
	// removes selected meat from grill
	public void removeSelected() {
		trashSelected(); // for now
	}
	
	private boolean canFitAt(int index, Meat piece) {
		if (piece.type != Meat.Type.CHICKEN)
			return meat[index] == null;
		else {
			return index + 1 < meat.length && 
					(open(index) || meat[index] == piece)
					&& (open(index + 1) || meat[index + 1] == piece);
		}
	}
	
	private boolean canFitAt(int index, Meat.Type type) {
		if (type != Meat.Type.CHICKEN)
			return meat[index] == null;
		else {
			return index + 1 < meat.length && (open(index)) && open(index + 1);
		}
	}
	
	// will this type of meat fit at mousedOver?
	private boolean canFit(Meat piece) {
		return canFitAt(mousedOver, piece);
	}
	
	// will this type of meat fit at mousedOver?
	private boolean canFit(Meat.Type type) {
		return canFitAt(mousedOver, type);
	}

	// drops spice at mousedOver index
	public void dropSpice() {
		if (meat[mousedOver] == null) throw new java.lang.IllegalArgumentException();
		meat[mousedOver].spice();
	}
	
	// drops selected meat into trash
	public void trashSelected() {
		if (!meatSelected()) throw new java.lang.IllegalArgumentException();
		
		for (Meat m : selectedSet) {
			meat[m.index1] = null;
			if (m.type == Meat.Type.CHICKEN) meat[m.index2] = null;
		}
	}
	
	// moves meat from selected to mousedOver
	public void move() {
		if (!mousedOver()) throw new java.lang.IllegalArgumentException();
		
		int grillIndex = mousedOver;
		int selectedIndex = 0;
		while (selectedIndex < selectedSet.size() && grillIndex < this.meat.length) {
			Meat current = selectedSet.get(selectedIndex);
			if (current == null) {
				selectedIndex++;
				continue;
			}
			if (this.canFitAt(grillIndex, current)) {
				moveFrom(current.index1, grillIndex);
				selectedIndex++;
			}
			grillIndex++;
		}
		
		selectedSet.clear();
	}
	
	public void moveFrom(int origIndex, int newIndex) {
		Meat toMove = meat[origIndex];

		// we null this out early because we don't want to null it at the end,
		// when it might actually have the moved meat
		meat[origIndex] = null;
		
		if (toMove.chicken()) {
			meat[origIndex + 1] = null;
		}

		meat[newIndex] = toMove;
		meat[newIndex].setIndex(newIndex);
		
		if (toMove.chicken()) {
			meat[newIndex + 1] = meat[newIndex];
		}
	}
	
	public boolean open(int index) {
		return (meat[index] == null);
	}
	
	public boolean newMeatSelected() {
		return this.selected == Selected.BEEF || this.selected == Selected.CHICKEN || this.selected == Selected.LAMB;
	}
	
	public boolean meatSelected() {
		return this.selectedSet.size() > 0;
	}
	
	public boolean mousedOver() {
		return this.mousedOver >= 0;
	}
}
