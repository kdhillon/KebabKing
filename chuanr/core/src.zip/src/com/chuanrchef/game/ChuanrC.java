package com.chuanrchef.game;

import com.badlogic.gdx.Game;

public class ChuanrC extends Game {
	public static boolean english = false;
	public static int width;
	public static int height; 
	
	Profile profile;
	
	// these guys are here so they can be drawn at all times
	Background bg;
	Grill grill;
	CustomerManager cm;
	
	// these three screens are permanent
	MainMenuScreen mainMenu;
	KitchenScreen kitchen;
	//StoreScreen store;
	
	// Summary Screens are temporary
	
	@Override
	public void create () {
		// load assets
		Assets.load();
		
		// load this from device in the future (only thing that needs to be saved)
		this.profile = new Profile();
		
		// load background which will always be present  
		bg = new Background(profile); 
		
		// load grill which will always be present
		grill = new Grill(profile);
		
		// load customer manager which will always be present
		cm = new CustomerManager(profile);
		
		// initialize screen
		mainMenu = new MainMenuScreen(this);
		setScreen(mainMenu);
	}
	
	// switch from main to kitchen
	public void startDay() {
		kitchen = new KitchenScreen(this);
		
		this.setScreen(kitchen);		
	}
	
	// switch from kitchen screen to summary screen
	public void endDay() {
		SummaryScreen summary = new SummaryScreen(kitchen);
		
		kitchen = null; // hopefully save some memory here
		this.setScreen(summary);
	}
	
	public void summaryToMain() {
		this.setScreen(mainMenu);
	}
	
	// go to pause screen
	public void pause() {
		
	}
	
	// switch to store screen
	public void store() {
		
	}
	
	// switch to main menu screen
	public void menu() {
		
	}
	
}
