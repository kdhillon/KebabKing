package com.chuanrchef.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Background {
	static Color daySky = new Color(.7f, .95f, 1f, 1);
	static Color nightSky = new Color(.1f, .1f, .2f, 1);
	static float nightStartTime = 15; // when night transition starts

	// background based on where the player is, what time of day, etc.
	float timeElapsed;

	TextureRegion bg; 

	Color currentColor;

	float nightRate = 0.05f;
	float rDif = nightSky.r - daySky.r;
	float gDif = nightSky.g - daySky.g;
	float bDif = nightSky.b - daySky.b;
	boolean fullNight;
	
	
	boolean active;


	public Background(Profile profile) {
		this.timeElapsed = 0;
		this.bg = Assets.bg1;

		this.active = false;
		this.currentColor = daySky.cpy();
	}

	public void activate() {
		this.currentColor = daySky.cpy();
		this.fullNight = false;
		this.active = true;
		this.timeElapsed = 0;
	}
	
	public void deactivate() {
		this.active = false;
	}

	public void act(float delta) {
		this.timeElapsed += delta;
		
		if (this.active && this.timeElapsed > nightStartTime) {

			if (!fullNight) {
				// fade towards night
				this.currentColor.r += rDif * delta * nightRate;
				this.currentColor.g += gDif * delta * nightRate;
				this.currentColor.b += bDif * delta * nightRate;
				if (this.currentColor.g <= nightSky.g) {
					fullNight = true;
					this.currentColor = nightSky.cpy();
				}
			}
		}
	}

	public void draw(SpriteBatch batch) {
		Gdx.gl.glClearColor(currentColor.r, currentColor.g, currentColor.b, currentColor.a);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


		// draw the background filling entire screen
		batch.draw(bg, 0, 0, ChuanrC.width, ChuanrC.height);
	}



}
