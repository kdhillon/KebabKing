package com.chuanrchef.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;

public class Assets {
	final static float GRILL_ANIMATION_TIME = .25f;
	final static int GRILL_ANIMATION_FRAMES = 1;
	final static float CUSTOMER_ANIMATION_TIME = .25f;
	final static int CUSTOMER_ANIMATION_FRAMES = 1;
		
	public static BitmapFont fontHud;
	public static BitmapFont fontOrder;
	
	public static BitmapFont china24;
	public static BitmapFont china32;
	public static BitmapFont china44;
	public static BitmapFont china60;
	public static BitmapFont china80;
	public static BitmapFont china100;
	public static BitmapFont china120;
	
	public static BitmapFont chinese32;
	public static BitmapFont chinese70;
	
	static TextureAtlas atlas;
	
	static TextureRegion title;
//	static TextureRegion start;
//	static TextureRegion store;
//	static TextureRegion quit;

	static Animation grillMid;
	static Animation grillLeft;
	static Animation grillRight;
	
	static Animation customerIdle;
	static Animation customerWalking;
	
	static Animation teenIdle;
	static Animation teenWalkLeft;
	static Animation teenWalkRight;
	static Animation teenWalkDown;
	static Animation teenWalkUp;
	
	static Animation manIdle;
	static Animation manWalkLeft;
	static Animation manWalkRight;
	static Animation manWalkDown;
	static Animation manWalkUp;
	
	static Animation touristIdle;
	static Animation touristWalkLeft;
	static Animation touristWalkRight;
	static Animation touristWalkDown;
	static Animation touristWalkUp;
	
	static Animation oldWomanIdle;
	static Animation oldWomanWalkLeft;
	static Animation oldWomanWalkRight;
	static Animation oldWomanWalkDown;
	static Animation oldWomanWalkUp;
	
	static Animation oldManStingyIdle;
	static Animation oldManStingyWalkLeft;
	static Animation oldManStingyWalkRight;
	static Animation oldManStingyWalkDown;
	static Animation oldManStingyWalkUp;
	
	static Animation policeIdle;
	static Animation policeWalkRight;
	static Animation policeWalkDown;
	static Animation policeWalkUp;	
	
	
	static TextureRegion chuanrChickenRaw;
	static TextureRegion chuanrChickenCooked;
	static TextureRegion chuanrChickenRawSpice;
	static TextureRegion chuanrChickenCookedSpice;
	static TextureRegion chuanrChickenBurnt;
	static TextureRegion chuanrChickenGhost;

	static TextureRegion chuanrBeefRaw;
	static TextureRegion chuanrBeefCooked;
	static TextureRegion chuanrBeefRawSpice;
	static TextureRegion chuanrBeefCookedSpice;
	static TextureRegion chuanrBeefBurnt;
	static TextureRegion chuanrBeefGhost;

	static TextureRegion chuanrLambRaw;
	static TextureRegion chuanrLambCooked;
	static TextureRegion chuanrLambRawSpice;
	static TextureRegion chuanrLambCookedSpice;
	static TextureRegion chuanrLambBurnt;
	static TextureRegion chuanrLambGhost;

	static TextureRegion beefBox;
	static TextureRegion chickenBox;
	static TextureRegion lambBox;
	static TextureRegion beerBox;
	static TextureRegion spiceBox;
	static TextureRegion trashBox;
	
	static TextureRegion beefIcon;
	static TextureRegion chickenIcon;
	static TextureRegion lambIcon;
	static TextureRegion beefSpicyIcon;
	static TextureRegion chickenSpicyIcon;
	static TextureRegion lambSpicyIcon;
	static TextureRegion beerIcon;
	
	static TextureRegion bg1;
	
	static TextureRegion speech;
	
	static TextureRegion white;
	
	
//	static Animation
	
	// static class containing relevant images, etc
	// should prepare animations and set regions to the appropriate size
	public static void load() {
		System.out.println("loading assets");
		atlas = new TextureAtlas(Gdx.files.internal("atlas1.atlas"));
		
		fontHud = new BitmapFont(Gdx.files.internal("data/droid50.fnt"), false);
		fontOrder = new BitmapFont(Gdx.files.internal("data/droid30.fnt"), false);
		fontOrder.setColor(Color.BLACK);
				
		
		FreeTypeFontGenerator msgothic = new FreeTypeFontGenerator(Gdx.files.internal("data/msgothic.ttc"));
		FreeTypeFontParameter params1 = new FreeTypeFontParameter();
		params1.size = 70;
		params1.characters = "开始一天 1234567890";
		chinese70 = msgothic.generateFont(params1);
		
		FreeTypeFontParameter params2 = new FreeTypeFontParameter();
		params2.size = 32;
		params2.characters = "¥: 1234567890.";
		chinese32 = msgothic.generateFont(params2);
		
		String fontClass = "gang";

		china24 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "32.fnt"), false);
		china32 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "44.fnt"), false);
		china44 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "44.fnt"), false);
		china60 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "60.fnt"), false);
		china80 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "80.fnt"), false);
		china100 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "100.fnt"), false);
		china120 = new BitmapFont(Gdx.files.internal("data/" + fontClass + "120.fnt"), false);
		
		speech = getTexture("speech");
		
		white = getTexture("whitepixel");
		
		title = getTexture("title");
//		start = getTexture("start");
//		store = getTexture("store");
//		quit = getTexture("quit");
		
		beefBox = getTexture("beefbox");
		lambBox = getTexture("lambbox");
		chickenBox = getTexture("chickenbox");
		beerBox = getTexture("beerbox");
		spiceBox = getTexture("spicebox");
		trashBox = getTexture("trashbox");
		
		chuanrChickenRaw = getTexture("chicken_raw");
		chuanrChickenCooked = getTexture("chicken_cooked");
		chuanrChickenRawSpice = getTexture("chicken_raw_spice");
		chuanrChickenCookedSpice = getTexture("chicken_cooked_spice");
		chuanrChickenBurnt = getTexture("chicken_burnt");
//		chuanrChickenGhost = getTexture("chicken_raw_ghost");
		
		chuanrBeefRaw = getTexture("beef_raw");
		chuanrBeefCooked = getTexture("beef_cooked");
		chuanrBeefRawSpice = getTexture("beef_raw_spice");
		chuanrBeefCookedSpice = getTexture("beef_cooked_spice");
		chuanrBeefBurnt = getTexture("beef_burnt");
//		chuanrBeefGhost = getTexture("beef_raw_ghost");
		
		chuanrLambRaw = getTexture("lamb_raw");
		chuanrLambCooked = getTexture("lamb_cooked");
		chuanrLambRawSpice = getTexture("lamb_raw_spice");
		chuanrLambCookedSpice = getTexture("lamb_cooked_spice");
		chuanrLambBurnt = getTexture("lamb_burnt");
//		chuanrLambGhost = getTexture("lamb_raw_ghost");
		
		grillMid = createAnimation("grillcenter", GRILL_ANIMATION_TIME, GRILL_ANIMATION_FRAMES);
		grillLeft = createAnimation("grillleft", GRILL_ANIMATION_TIME, GRILL_ANIMATION_FRAMES);
		grillRight = createAnimation("grillright", GRILL_ANIMATION_TIME, GRILL_ANIMATION_FRAMES);
	
		teenIdle = createAnimation("teen_down", CUSTOMER_ANIMATION_TIME, 1);
		teenWalkLeft = createAnimation("teen_walk_left", CUSTOMER_ANIMATION_TIME, 2);
		teenWalkRight = createAnimation("teen_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		teenWalkDown = createAnimation("teen_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		teenWalkUp = createAnimation("teen_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		
		manIdle = createAnimation("man_down", CUSTOMER_ANIMATION_TIME, 1);
		manWalkLeft = createAnimation("man_walk_left", CUSTOMER_ANIMATION_TIME, 2);
		manWalkRight = createAnimation("man_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		manWalkDown = createAnimation("man_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		manWalkUp = createAnimation("man_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		
		oldWomanIdle = createAnimation("old_woman_down", CUSTOMER_ANIMATION_TIME, 1);
		oldWomanWalkLeft = createAnimation("old_woman_walk_left", CUSTOMER_ANIMATION_TIME, 2);
		oldWomanWalkRight = createAnimation("old_woman_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		oldWomanWalkUp = createAnimation("old_woman_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		oldWomanWalkDown = createAnimation("old_woman_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		
		oldManStingyIdle = createAnimation("old_man_stingy_down", CUSTOMER_ANIMATION_TIME, 1);
		oldManStingyWalkLeft = createAnimation("old_man_stingy_walk_left", CUSTOMER_ANIMATION_TIME, 2);
		oldManStingyWalkRight = createAnimation("old_man_stingy_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		oldManStingyWalkUp = createAnimation("old_man_stingy_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		oldManStingyWalkDown = createAnimation("old_man_stingy_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		
		policeIdle = createAnimation("police_down", CUSTOMER_ANIMATION_TIME, 1);
		policeWalkRight = createAnimation("police_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		policeWalkUp = createAnimation("police_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		policeWalkDown = createAnimation("police_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		
		touristIdle = createAnimation("tourist_down", CUSTOMER_ANIMATION_TIME, 1);
		touristWalkLeft = createAnimation("tourist_walk_left", CUSTOMER_ANIMATION_TIME, 2);
		touristWalkRight = createAnimation("tourist_walk_right", CUSTOMER_ANIMATION_TIME, 2);
		touristWalkDown = createAnimation("tourist_walk_down", CUSTOMER_ANIMATION_TIME, 2);
		touristWalkUp = createAnimation("tourist_walk_up", CUSTOMER_ANIMATION_TIME, 2);
		
		chickenIcon = getTexture("chicken_icon");
		beefIcon = getTexture("beef_icon");
		lambIcon = getTexture("lamb_icon");
		chickenSpicyIcon = getTexture("chicken_sp_icon");
		beefSpicyIcon = getTexture("beef_sp_icon");
		lambSpicyIcon = getTexture("lamb_sp_icon");
		beerIcon = getTexture("beer_icon");

		
		bg1 = getTexture("bg1");
		
		
	}
	
	public static Animation createAnimation(String region, float time, int columns) {
		TextureRegion walkSheet = getTexture(region);
		TextureRegion[][] textureArray = walkSheet.split(walkSheet.getRegionWidth()/columns, walkSheet.getRegionHeight()/1);
		Animation animation = new Animation(time, textureArray[0]);
		animation.setPlayMode(Animation.PlayMode.LOOP);
		return animation;
	}
	

	public static TextureRegion getTexture(String name) {
		TextureRegion toReturn = atlas.findRegion(name);
		if (toReturn == null) throw new NullPointerException("cant find '" + name +"'");
		return toReturn;
	}
	
}


