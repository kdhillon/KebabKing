package com.chuanrchef.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MainMenuScreen implements Screen {
	ChuanrC master;
	Profile profile;
	Background bg; 
	Grill grill;
	CustomerManager cm;

	SpriteBatch batch;

	public MainMenuScreen(ChuanrC master) {	
		this.master = master;
		this.profile = master.profile;
		this.bg = master.bg;
		this.grill = master.grill;
		this.cm = master.cm;
		
		this.batch = new SpriteBatch();
	}


	@Override
	public void render(float delta) {
		update(delta);

		batch.begin();
		bg.draw(batch);
		cm.draw(batch);
		grill.draw(batch);

		drawText();

		batch.end();
	}

	// actually run a game loop
	public void update(float delta) {	
		// just for testing
		boolean fastForward = false;
		if (Gdx.input.isKeyPressed(Keys.F))
			fastForward = true;

		grill.mousedOver = -1;
		grill.mousedOverTrash = false;
		cm.mousedOver = null;

		if (fastForward) {
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
			bg.act(delta);
			cm.act(delta);
		}
		else {
			bg.act(delta);
			cm.act(delta);
		}
	}
	
	// xiaomi (get specs on popular handsets)
	public void drawText() {
		if (ChuanrC.english) {
			float xTitle1 = 0.05f;
			float yTitle1 = 0.9f;
			Assets.china120.draw(batch, " Kebab", ChuanrC.width * xTitle1, ChuanrC.height * yTitle1);

			float xTitle2 = 0.17f;
			float yTitle2 = 0.75f;
			Assets.china120.draw(batch, "Chef!", ChuanrC.width * xTitle2, ChuanrC.height * yTitle2);	
			
			// tap to continue
			float xContinue = 0.15f;
			float yContinue = 0.5f;
			Assets.china60.draw(batch, "Start Day " + (profile.daysWorked + 1) + "!", ChuanrC.width * xContinue, ChuanrC.height * yContinue);
		}
		else {
			float yTitle1 = 0.50f;
			batch.draw(Assets.title, 0, yTitle1 * ChuanrC.height);
			
			float xStart = 0.15f;
			float yStart = 0.45f;
			Assets.chinese70.draw(batch, "开始一天 " + (profile.daysWorked + 1), ChuanrC.width * xStart, ChuanrC.height * yStart);
		}
	}
	
	
	public void transition() {
		this.master.startDay();
	}
	
	
	@Override
	public void resize(int width, int height) {
		ChuanrC.width = width;
		ChuanrC.height = height;

		// initialize once
		if (KitchenScreen.UNIT_HEIGHT == 0 && KitchenScreen.UNIT_WIDTH == 0) {
			KitchenScreen.UNIT_WIDTH = (int) (ChuanrC.width / KitchenScreen.WIDTH);
			KitchenScreen.UNIT_HEIGHT = (int) (ChuanrC.height / KitchenScreen.HEIGHT);
		}
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		Gdx.input.setInputProcessor(new InputAdapter () {
			public boolean touchDown (int x, int y, int pointer, int button) {
				return true; // return true to indicate the event was handled
			}
			public boolean touchUp (int x, int y, int pointer, int button) {
				transition();
				return true; // return true to indicate the event was handled
			}
		});
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}



}
