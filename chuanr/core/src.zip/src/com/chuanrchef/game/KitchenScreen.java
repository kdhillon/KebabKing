package com.chuanrchef.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Buttons;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class KitchenScreen implements Screen {
	static final int WIDTH  = 12; // approx. 3:4 ratio
	static final int HEIGHT = 16; // 3:4 ratio approximation
	static final int BUFFER = 0; // distance between each item

	static final float DAY_LENGTH = 120; // 2 minutes per day

	// hud values
	static final int MONEY_X = 9;
	static final int MONEY_Y = 16;


	static int UNIT_WIDTH;
	static int UNIT_HEIGHT;

	// probably shouldn't be here but thats ok
	static final float BEER_SELL_PRICE = 5;
	static final float BEER_BUY_PRICE = 3;


	ChuanrC master;
	Profile profile;

	float time;
	SpriteBatch batch;
	Grill grill;
	CustomerManager cm;
	Background bg;

	boolean paused = false;

	float currentMoney;

	float moneyEarnedToday;
	float moneySpentToday;

	float happyCustomers;

	// A new Kitchen Screen is created every time the player starts a new day.
	// handles user input and the main render / update loop
	public KitchenScreen(ChuanrC master) {
		this.master = master;

		this.profile = master.profile;
		this.bg = master.bg;
		this.bg.activate();
		this.cm = master.cm;

		this.time = DAY_LENGTH;

		this.currentMoney = profile.money;

		batch = new SpriteBatch();

		grill = master.grill;
		grill.activate(this);

		// clear cm for each day
		cm.activate();
		//		bg.activate();

		Gdx.input.setInputProcessor(new InputAdapter () {
			public boolean touchDown (int x, int y, int pointer, int button) {
				grill.touchInput(x, y); // handle all types of clicks the same.
				return true; // return true to indicate the event was handled
			}
			public boolean touchUp (int x, int y, int pointer, int button) {
				grill.release(x, y);
				return true; // return true to indicate the event was handled
			}
		});

		// required to have a smooth thing
		this.render(0);
		//		paused = true;
	}

	@Override
	public void render(float delta) {

		if (!paused) {
			update(delta);
		}

		batch.begin();
		bg.draw(batch);
		cm.draw(batch);
		grill.draw(batch);
		drawMoney(batch);
		batch.end();
	}

	// actually run a game loop
	public void update(float delta) {	
		// just for testing
		boolean fastForward = false;
		if (Gdx.input.isKeyPressed(Keys.F))
			fastForward = true;

		if (Gdx.input.isButtonPressed(Buttons.LEFT))
			grill.holdInput(Gdx.input.getX(), Gdx.input.getY());
		else {
			grill.mousedOver = -1;
			grill.mousedOverTrash = false;
			cm.mousedOver = null;
		}

		if (fastForward) {
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			bg.act(delta);
			cm.act(delta);
			grill.act(delta);
			this.time -= 8*delta;
		}
		else {
			bg.act(delta);
			cm.act(delta);

			grill.act(delta);

			// countdown
			this.time -= delta;
		}
		if (this.time < 0) finishDay();
	}


	public void drawMoney(SpriteBatch batch) {
		if (ChuanrC.english) {
			Assets.china32.draw(batch, "$" + String.format("%.1f", currentMoney), MONEY_X * UNIT_WIDTH, MONEY_Y*UNIT_HEIGHT - UNIT_HEIGHT/2);
			Assets.china32.draw(batch, (int) (time / 60) + ":" + String.format("%02d", (int) (time % 60)) , MONEY_X * UNIT_WIDTH, MONEY_Y*UNIT_HEIGHT - UNIT_HEIGHT*1.5f);	
		}
		else {
			Assets.chinese32.draw(batch, "¥" + String.format("%.1f", currentMoney), MONEY_X * UNIT_WIDTH, MONEY_Y*UNIT_HEIGHT - UNIT_HEIGHT/2);
			Assets.chinese32.draw(batch, (int) (time / 60) + ":" + String.format("%02d", (int) (time % 60)) , MONEY_X * UNIT_WIDTH, MONEY_Y*UNIT_HEIGHT - UNIT_HEIGHT*1.5f);	
		}
	}

	// converts 
	public static int convertWidth(int width) {
		return width * UNIT_WIDTH - 2*BUFFER;
	}

	public static int convertHeight(int height) {
		return height * UNIT_HEIGHT - 2*BUFFER;
	}

	public static int convertXWithBuffer(int unit_x) {
		return convertX(unit_x) + BUFFER;
	}

	public static int convertYWithBuffer(int unit_y) {
		return convertY(unit_y) + BUFFER;
	}

	public static int convertX(int unit_x) {
		return unit_x * UNIT_WIDTH;
	}

	public static int convertY(int unit_y) {
		return unit_y * UNIT_HEIGHT;
	}

	@Override
	public void resize(int width, int height) {
		ChuanrC.width = width;
		ChuanrC.height = height;

		// initialize once
		if (UNIT_HEIGHT == 0 && UNIT_WIDTH == 0) {
			UNIT_WIDTH = (int) (ChuanrC.width / WIDTH);
			UNIT_HEIGHT = (int) (ChuanrC.height / HEIGHT);
		}

		// don't need this, because screen auto-resizes
		//		UNIT_WIDTH = width / WIDTH;
		//		UNIT_HEIGHT = height / HEIGHT;
	}

	public void dropMeatOnGrill(Meat.Type type) {
		if (!canAfford(Meat.getBuyPrice(type))) return;

		spendMoney(Meat.getBuyPrice(type));
		grill.dropMeat(type);
	}

	public boolean canAfford(float price) {
		return currentMoney >= price;
	}

	public void earnMoney(float money) {
		this.moneyEarnedToday += money;
		this.currentMoney += money;
		//		System.out.println("money: " + currentMoney);
	}

	public void spendMoney(float money) {
		currentMoney -= money;
		moneySpentToday += money;
		//		System.out.println("money: " + currentMoney);
	}

	public static int getUnitX(int x) {
		return x / UNIT_WIDTH;
	}

	public static int getUnitY(int y) {
		return ((ChuanrC.height - y) / UNIT_HEIGHT);
	}

	public void finishDay() {			
		// switch to summary screen
		master.endDay();
	}

	/** returns reputation for day, between 0.5 and 5.0 */
	public float calculateReputation() {		
		// simply average the reputations and round)
		int reputation = (int) (2.0 * cm.totalSatisfaction / cm.totalCustomers + 0.5);		

		float rep = reputation / 2.0f;
		if (rep == 0) rep = 0.5f;

		return rep;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("show()");
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		System.out.println("hide()");
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		this.paused = true;
		System.out.println("pause()");
	}

	@Override
	public void resume() {
		this.paused = false;
		// TODO Auto-generated method stub
		System.out.println("resume()");
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		System.out.println("dispose()");
	}

}
