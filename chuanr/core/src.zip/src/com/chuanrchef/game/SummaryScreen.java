package com.chuanrchef.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

// this screen summarizes your sales for the day
public class SummaryScreen implements Screen {	
	static float timeBetweenStars = 0.5f;
	static float timeBetweenLines = .7f;
	static float line1 = 1;
	static float line2 = line1 + timeBetweenLines;
	static float line3 = line2 + timeBetweenLines;
	static float line4 = line3 + timeBetweenLines;


	Profile profile;
	Background bg; 

	KitchenScreen kitchen;
	Grill grill;
	CustomerManager cm;

	SpriteBatch batch;


	//	float revenue;
	//	float expenses;

	float timeElapsed;
	float profit;
	int customersServed;
	int sickCount;
	float rating; // between 0.5 and 5.0
	float forceWait;
	float nextStar;
	float starsToDraw;
	boolean drawHalfStar; 

	public SummaryScreen(KitchenScreen kitchen) {
		this.batch = kitchen.batch;
		this.profile = kitchen.profile;
		this.bg = kitchen.bg;
		this.cm = kitchen.cm;
		this.kitchen = kitchen;

		timeElapsed = 0;

		// refund any meat that's on the grill:
		float refund = 0;
		for (int i = 0; i < kitchen.grill.meat.length; i++) {
			Meat meat = kitchen.grill.meat[i];
			if (meat == null) continue;
			if (meat.state == Meat.State.BURNT) continue;

			refund += Meat.getBuyPrice(meat.type);
		}
		kitchen.currentMoney += refund;

		// update profit
		this.profit = kitchen.currentMoney - profile.money;

		// customers served:
		this.customersServed = kitchen.cm.totalCustomers;

		// sicknesses
		this.sickCount = cm.totalSick;

		// save rating
		this.rating = kitchen.calculateReputation();
		
		this.forceWait = line4 + (int) (rating + 0.5f) * timeBetweenStars + timeBetweenLines;
		this.nextStar = line4 + timeBetweenStars;

		// save to profile
		profile.daysWorked++;
		profile.updateRepuation(kitchen.calculateReputation());
		profile.money = kitchen.currentMoney;

		this.grill = kitchen.grill;
		grill.deactivate(); // deactivate grill
		this.cm = kitchen.cm;
		cm.deactivate();
		bg.deactivate();


		Gdx.input.setInputProcessor(new InputAdapter () {
			public boolean touchDown (int x, int y, int pointer, int button) {
				return true; // return true to indicate the event was handled
			}
			public boolean touchUp (int x, int y, int pointer, int button) {
				transition();
				return true; // return true to indicate the event was handled
			}
		});
	}


	@Override
	public void render(float delta) {
		update(delta);

		batch.begin();
		bg.draw(batch);
		cm.draw(batch);
		grill.draw(batch);

		drawText();

		batch.end();
	}

	// actually run a game loop
	public void update(float delta) {	
		this.timeElapsed += delta;
		
		bg.act(delta);
		cm.act(delta);
	}


	public void drawText() {
		// Day x:
		float xLeft = 0.25f;
		float xRight = 0.65f;

		float xTitle = 0.3f;
		float yTitle = 0.7f;
		Assets.china60.draw(batch, "Day " + profile.daysWorked + ":", ChuanrC.width * xTitle, ChuanrC.height * yTitle);


		if (timeElapsed > line1) {
			// Customers served 10
			float yCustomer = 0.6f;
			Assets.china24.draw(batch, "Customers: ", ChuanrC.width * xLeft, ChuanrC.height * yCustomer);
			Assets.china24.draw(batch, "" + customersServed, ChuanrC.width * xRight, ChuanrC.height * yCustomer);

		}

		//		// Revenue: 10
		//		float yRevenue = 0.6f;
		//		Assets.china24.draw(batch, "Revenue: ", ChuanrC.width * xFactor, ChuanrC.height * yRevenue);
		//
		//		// Expenses: 10
		//		float yExpenses = 0.6f;
		//		Assets.china24.draw(batch, "Expenses: ", ChuanrC.width * xFactor, ChuanrC.height * yExpenses);


		if (timeElapsed > line2) {
			// Profit today: 10
			float yProfit = 0.55f;
			Assets.china24.draw(batch, "Profit: ", ChuanrC.width * xLeft, ChuanrC.height * yProfit);
			Assets.china24.draw(batch, "$" + profit, ChuanrC.width * xRight, ChuanrC.height * yProfit);

		}

		if (timeElapsed > line3) {
			// Sick customers: 10
			float ySick = 0.50f;
			Assets.china24.draw(batch, "People Sick: ", ChuanrC.width * xLeft, ChuanrC.height * ySick);
			Assets.china24.draw(batch, "" + sickCount, ChuanrC.width * xRight, ChuanrC.height * ySick);
		}

		if (timeElapsed > line4) {
			// Reputation: 5
			float yRep = 0.45f;
			Assets.china24.draw(batch, "Rating: ", ChuanrC.width * xLeft, ChuanrC.height * yRep);
			
			if (timeElapsed > nextStar && starsToDraw + 1 <= rating) {
				System.out.println("starsToDraw++");
				starsToDraw++;
				nextStar = nextStar + timeBetweenStars;
			}
			
			// if should draw half star
			if (timeElapsed > nextStar && !drawHalfStar && rating * 2 % 2 == 1) {
				drawHalfStar = true;
			}
			
			String toDraw = "";
			for (int i = 0; i < starsToDraw; i++) toDraw = toDraw + "X";
			if (drawHalfStar) toDraw += "x";
			
			Assets.china24.draw(batch, toDraw, ChuanrC.width * xRight, ChuanrC.height * yRep);				
		}

		if (timeElapsed > forceWait) {	
			// tap to continue
			float xContinue = 0.15f;
			float yContinue = 0.4f;
			Assets.china32.draw(batch, "Tap to Continue!", ChuanrC.width * xContinue, ChuanrC.height * yContinue);
		}
	}


	public void transition() {
		if (timeElapsed > forceWait)
			kitchen.master.summaryToMain();
	}


	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void show() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}



}
